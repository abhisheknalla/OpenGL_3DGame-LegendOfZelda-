#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_RED2 = { 255, 0, 0};
const color_t COLOR_HORN = { 255, 0, 0 };
const color_t COLOR_BROWN = { 173, 62, 0 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BLACK2 = { 0, 0, 0 };
const color_t COLOR_BACKGROUND = { 108, 180, 255 };
const color_t COLOR_WATERBLUE = { 0, 106, 255 };
const color_t COLOR_WATERBLUE2 = { 0, 136, 255 };
const color_t COLOR_GREEN2 = { 0, 190, 0 };
const color_t COLOR_DARKGREEN = { 0, 90, 0 };
const color_t COLOR_WHITE = { 255, 255, 70 };
const color_t COLOR_FLAG = { 255, 255, 255 };
const color_t COLOR_ROCKS = { 134, 19, 0 };
const color_t COLOR_GREEN3 = { 0, 100, 0 };
const color_t COLOR_CANON = {255,0,121};
const color_t COLOR_GOLD = {255,215,0};
const color_t COLOR_BARREL = {157,100,0};
const color_t COLOR_GIFT = {255,0,160};
const color_t COLOR_LAND = {190,130,0};
const color_t COLOR_BOOST = {206,133,135};
const color_t COLOR_LINK = {145,255,0};
const color_t COLOR_FACE = {255,255,100};
const color_t COLOR_GREY = {105,105,105};
